﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo1PARADIGMA
{
    internal class Program
    {
        // Función que implementa la búsqueda binaria
        static int Buscar(int[] arr, int valor, int izquierda, int derecha)
        {
            if (derecha >= izquierda)
            {
                int medio = izquierda + (derecha - izquierda) / 2;

                // Si el valor está en el medio
                if (arr[medio] == valor)
                    return medio;

                // Si el valor es menor que el medio, entonces debe estar en la mitad izquierda
                if (arr[medio] > valor)
                    return Buscar(arr, valor, izquierda, medio - 1);

                // Si el valor es mayor que el medio, entonces debe estar en la mitad derecha
                return Buscar(arr, valor, medio + 1, derecha);
            }

            // Si no se encuentra el valor
            return -1;
        }


        static void Main(string[] args)
        {
            //Ejrmplo1: BÚSQUEDA BINARIA
            /*La búsqueda binaria es un algoritmo clásico que utiliza el paradigma de "Divide y vencerás"
            para encontrar un elemento en un arreglo ordenado.*/

            Console.WriteLine("................\nBÚSQUEDA BINARIA\n................");

            int[] arreglo = { 2, 3, 4, 10, 40 };
            Console.WriteLine("Arreglo: [" + string.Join(", ", arreglo) + "]");
            int valorABuscar;

            Console.WriteLine("Ingrese el valor a buscar:");
            valorABuscar=int.Parse(Console.ReadLine());

            int resultado = Buscar(arreglo, valorABuscar, 0, arreglo.Length - 1);

            if (resultado != -1)
                Console.WriteLine("Elemento encontrado en el índice: " + resultado);
            else
                Console.WriteLine("Elemento no encontrado");

            Console.ReadKey();
        }
    }
}
