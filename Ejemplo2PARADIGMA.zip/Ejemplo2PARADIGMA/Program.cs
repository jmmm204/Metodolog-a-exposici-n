﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejemplo2PARADIGMA
{
    internal class Program
    {
        // Función para dividir el arreglo y aplicar el algoritmo Merge Sort
        static void Ordenar(int[] arr, int izquierda, int derecha)
        {
            if (izquierda < derecha)
            {
                // Encuentra el punto medio
                int medio = (izquierda + derecha) / 2;

                // Aplica Merge Sort en la primera mitad
                Ordenar(arr, izquierda, medio);

                // Aplica Merge Sort en la segunda mitad
                Ordenar(arr, medio + 1, derecha);

                // Combina las dos mitades
                Mezclar(arr, izquierda, medio, derecha);
            }
        }

        // Función para combinar dos mitades de un arreglo
        static void Mezclar(int[] arr, int izquierda, int medio, int derecha)
        {
            int n1 = medio - izquierda + 1;
            int n2 = derecha - medio;

            // Arreglos temporales
            int[] L = new int[n1];
            int[] R = new int[n2];

            // Copia los datos a los arreglos temporales
            Array.Copy(arr, izquierda, L, 0, n1);
            Array.Copy(arr, medio + 1, R, 0, n2);

            int i = 0, j = 0;
            int k = izquierda;

            // Mezcla los arreglos temporales de vuelta en el original
            while (i < n1 && j < n2)
            {
                if (L[i] <= R[j])
                {
                    arr[k] = L[i];
                    i++;
                }
                else
                {
                    arr[k] = R[j];
                    j++;
                }
                k++;
            }

            // Copia los elementos restantes de L[], si es que hay
            while (i < n1)
            {
                arr[k] = L[i];
                i++;
                k++;
            }

            // Copia los elementos restantes de R[], si es que hay
            while (j < n2)
            {
                arr[k] = R[j];
                j++;
                k++;
            }
        }

            static void Main(string[] args)
        {
            /*Merge Sort es un algoritmo de ordenamiento que también utiliza "Divide y vencerás".
             Se divide el arreglo en mitades, se ordena cada mitad de manera recursiva y luego 
             se combinan las dos mitades ordenadas.*/

            Console.WriteLine("..........\nMERGE SORT\n..........");
            int[] arreglo = { 12, 11, 13, 5, 6, 7 };
            Console.WriteLine("Arreglo original:");
            Console.WriteLine(string.Join(" ", arreglo));

            Ordenar(arreglo, 0, arreglo.Length - 1);

            Console.WriteLine("\nArreglo ordenado:");
            Console.WriteLine(string.Join(" ", arreglo));

            Console.ReadKey();
        }
    }
}
